import os
import imageio 
import numpy as np
import matplotlib.pyplot as plt


def get_images(img_pattern, img_filename, path='', n_images=3, ext='.png'):
    image_high_res = imageio.v2.imread(path + img_filename)

    images_low_res = []
    for img_num in range(n_images + 1):
        images_low_res.append(imageio.v2.imread(f'{path}{img_pattern}{img_num}{ext}'))
    
    return np.array(images_low_res), image_high_res

def histogram(img, n_levels=256):
    hist, _ = np.histogram(img.flatten(), bins=n_levels)
    return hist[:]

def histogram_accumulate(hist):
    return np.cumsum(hist)

def histogram_equalization(img, n_levels, hist_cumulative):
    n, m = img.shape
    
    # cria a imagem equalizada
    img_transformed = np.zeros([n,m]).astype(np.uint8)
    
    # para cada intensidade, iremos transformar seu valor no novo valor de intensidade 
    for z in range(n_levels):
        # computa o valor da  transfromação do pixel 
        s = ((n_levels - 1) / hist_cumulative[-1]) * hist_cumulative[z]
        
        # para cada pixel na imagem com intensidade 'z' iremos transformar em 's'
        img_transformed[np.where(img == z)] = s
        
    return img_transformed

def histogram_equalization_apply(imgs, n_levels=256, typeof='single'):
    # criando um histograma para cada imagem
    histograms = [histogram(img, n_levels) for img in imgs]
    # gerando um histograma acumulado para cada imagem
    histograms = [histogram_accumulate(hist) for hist in histograms]
    # gerando um histograma acumulado considerando todas as images
    histogram_all = np.sum(histograms, axis=0)
    print()

    out = []
    for i, img in enumerate(imgs):
        if typeof == 'single':
            print("equalizacao de uma imagem")
            img_t = histogram_equalization(img, n_levels, histograms[i])
        elif typeof == 'all':
            img_t = histogram_equalization(img, n_levels, histogram_all)        
        out.append(img_t)
    
    return out

def gamma_correction(img, gamma_p, max_intensity):
    return np.floor(max_intensity * (img / max_intensity) ** (1 / gamma_p))

def gamma_correction_apply(imgs, gamma_p, max_intensity=255):
    return [gamma_correction(img, gamma_p, max_intensity) for img in imgs]

def rmse(img, img_true):
    return '%.4f' % np.sqrt(np.mean((img - img_true)**2))

def main():
    img_pattern  = input('') # Type the low resolution image: 
    img_filename = input('') # Type the high resolution image filename: 
    method       = input('') # Type the method: 
    gamma_p      = float(input('')) # Enter the gamma parameter if method is F3: 
    # img_pattern  = '01_low'
    # img_filename = '01_high.png'
    # method       = '1'
    # gamma_p      = float('1') 

    images_low, image_high = get_images(img_pattern, img_filename, path='./')
    ######
    print(images_low.shape, image_high.shape, method)
    ######

    images_transformed = None
    if method == '0':
        images_transformed = images_low
    elif method == '1':
        images_transformed = histogram_equalization_apply(images_low, typeof='single')
    elif method == '2':
        images_transformed = histogram_equalization_apply(images_low, typeof='all')
    elif method == '3':
        images_transformed = gamma_correction_apply(images_low, gamma_p)
    n, m = image_high.shape
    super_resolution = np.zeros([n, m]).astype(np.uint8)

    super_resolution[::2, ::2]   = images_transformed[0]
    super_resolution[::2, 1::2]  = images_transformed[1]
    super_resolution[1::2, ::2]  = images_transformed[2]
    super_resolution[1::2, 1::2] = images_transformed[3]
    
    # print(super_resolution.shape)
    print(rmse(super_resolution, image_high))

if __name__ == '__main__':
    main()